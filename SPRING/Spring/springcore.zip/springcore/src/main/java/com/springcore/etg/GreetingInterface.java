package com.springcore.etg;

public interface GreetingInterface {
	public String sayGreeting(String name);
}
