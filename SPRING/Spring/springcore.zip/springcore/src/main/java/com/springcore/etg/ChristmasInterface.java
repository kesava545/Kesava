package com.springcore.etg;

public interface ChristmasInterface {
	public String happyChristmas(String message);
}
