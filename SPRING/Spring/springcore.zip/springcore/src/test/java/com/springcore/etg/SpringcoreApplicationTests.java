package com.springcore.etg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringcoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
